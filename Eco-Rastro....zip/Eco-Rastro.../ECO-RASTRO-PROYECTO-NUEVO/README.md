# ECO-RASTRO Android

Proyecto Android nativo con una interfaz WebView local.

## Compilar en GitHub
1. Extrae todo el contenido del ZIP.
2. Sube los archivos y carpetas a la raíz del repositorio GitHub, conservando la carpeta `.github/workflows`.
3. Abre Actions y ejecuta "Construir APK ECO-RASTRO".
4. Al terminar correctamente, descarga el artefacto `ECO-RASTRO-APK`.

No subas solamente este ZIP al repositorio: GitHub Actions necesita que el proyecto esté descomprimido en la raíz.
